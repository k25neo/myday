<div class="ds-editable-component js-editable-component" style="width: auto; height: auto;">
  <div class="ds-text-component" >
    <input class="form-control fullwidth" name="name" type="text"
      value="{{ $groupName or '' }}" readonly>
    <div class="edit_icon_container"><i class="fa fa-pencil" aria-hidden="true"></i></div>
    <div class="edit-btn__container">
      <div class="edit-btn edit-btn__apply js-edit-btn-apply">
        <i class="fa fa-check-circle" aria-hidden="true"></i>
      </div>
      <div class="edit-btn edit-btn__cancel js-edit-btn-cancel">
        <i class="fa fa-times-circle" aria-hidden="true"></i>
      </div>
    </div>
  </div>
</div>
