<!-- start board-content-component -->
<?php $__empty_1 = true; $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
  <div class="board-content-component">
    <div class="board-group">
      <div class="board-group-header">
        <div class="board-group-row">
        <div class="board-group-cell board-group-menu menu-cell-header js-board-group-menu">
          <div class="board-group-menu-box" style="border-color: orange; background-color: orange;">
            <i class="fa fa-caret-down" aria-hidden="true"></i>
          </div>
          <div class="board-group-menu-content">
            <div class="board-group-menu-item js-collapse-group">Свернуть группу</div>
            <div class="board-group-menu-item">Выбрать все элементы</div>
            
            
            
            
            
            
            
            <div class="board-group-menu-hr"></div>
            <div class="board-group-menu-item">
              <form action="<?php echo e(route('group.destroy', [$board->id, $group->id])); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('DELETE')); ?>

                <button>Удалить группу</button>
              </form>
            </div>
          </div>
        </div>
        <div class="board-group-cell name-cell-header" style="color: orange;">
          
          <form action="<?php echo e(route('group.update', [$board->id, $group->id])); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <?php echo e(method_field('PUT')); ?>

              <?php echo $__env->make('crm.board.partials.ds_editable', ['groupName' => $group->name], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          </form>
        </div>
        <div class="board-group-cell person-cell-header">Сотрудник</div>
        <div class="board-group-cell status-cell-header">Статус заявки</div>
        <div class="board-group-cell date-cell-header">Дата</div>
        <div class="board-group-cell sum-cell-header">Стоимость</div>
        <div class="board-group-cell btn-cell-header"></div>
        </div>
      </div>
      <div class="board-group-body">
        <?php $__currentLoopData = $group->tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php echo $__env->make('crm.board.partials.board_group_row',
          ['task'=>$task, 'group'=>$group, 'board'=>$board,
          'users'=>$task->users, 'comments'=>$task->comments->count()], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      <div class="board-group-footer">
        <div class="board-group-row">
          <div class="board-group-cell menu-cell"></div>
          <div class="board-group-cell checkbox-cell"></div>
          <div class="board-group-cell add-cell js-add-cell-component" style="border-left:8px solid orange;">
            <form action="<?php echo e(route('task.store', [$board->id, $group->id])); ?>" method="post">
              <?php echo e(csrf_field()); ?>

              <div class="add-cell-component ">
                <input type="text" name="name" value="" placeholder="+ Добавить" readonly>
                <button class="add-pulse-button">Добавить</button>
              </div>
            </form>
          </div>
          <div class="board-group-cell btn-cell-header"></div>
        </div>
        <div class="board-group-row flex-end">
          <div class="board-group-cell total-sum-cell">
            <input type="text" name="total" value="<?php echo e($group->tasks->sum('sum')); ?>" readonly title="Сумма">
          </div>
          <div class="board-group-cell btn-cell-header"></div>
        </div>
      </div>
    </div>
  </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
  <div class="message__green">
    Создайте группу
  </div>
<?php endif; ?>

<!-- end board-content-component -->
