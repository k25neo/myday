<?php $__env->startSection('content'); ?>
  <div class="content__container">
    <div class="content__header">
      <h1>Клиенты</h1>
    </div>
  </div>
<div class="content__container">
  <div class="content__main">
    <!-- begin board list -->

<div class="board__list">
  <div class="board__list_header">
    <div class="board__list_cell">Название:</div>
    <div class="board__list_cell">Описание:</div>
    <div class="board__list_cell">Действия:</div>
  </div>
    <?php $__empty_1 = true; $__currentLoopData = $boards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $board): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="board__list_row">
      <div class="board__list_cell">
        <a href="<?php echo e(route('board.show', $board->id)); ?>"><?php echo e($board->name); ?></a>
      </div>
      <div class="board__list_cell">
        <?php echo e($board->description); ?>

      </div>
      <div class="board__list_cell">
        <form action="<?php echo e(route( 'board.destroy', $board->id )); ?>" method="post">
          <?php echo e(csrf_field()); ?>

          <?php echo e(method_field('DELETE')); ?>

          <button><i class="fa fa-trash" aria-hidden="true"></i></button>
        </form>
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
      <div class="message__green">
        Создайте клиента
      </div>
    <?php endif; ?>
</div><!-- end board list -->

</div><!--content__main-->
</div><!--content__container-->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('crm.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>