  <form class="" action="<?php echo e(route('task.update', [$board->id, $group->id, $task->id])); ?>" method="post">
    <?php echo e(csrf_field()); ?>

    <?php echo e(method_field('PUT')); ?>

  <div class="board-group-row">
    <div class="board-group-cell menu-cell"></div>
    <div class="board-group-cell checkbox-cell"></div>
    <div class="board-group-cell name-cell" style="border-left:8px solid orange;">
      <input class="input-cell" type="text" name="name" value="<?php echo e($task->name); ?>" readonly>
      <div class="comment-open-icon
      <?php if($comments > 0): ?>
        no-empty
      <?php endif; ?>
      js-comment-open" data-task="<?php echo e($task->id); ?>">
        <i class="fa fa-comment-o" aria-hidden="true"></i>
        <?php if( $comments > 0 ): ?>
          <div class="comment-open-icon-count"><?php echo e($comments); ?></div>
        <?php endif; ?>
      </div>
    </div>
    <div class="board-group-cell person-cell">
      
      <div class="person-cell-component js-user-select" data-task="<?php echo e($task->id); ?>">
        <input type="hidden" name="users" value="<?php echo e($users->keys()); ?>" >
        <div class="person-image-wrapper">
          <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <img style="margin:0 -<?php echo e($users->count()); ?>px" data-id="<?php echo e($user->id); ?>" src="
            <?php if( !empty($user->image) ): ?>
              <?php echo e(asset('/storage/'.$user->image)); ?>

            <?php else: ?>
              /img/person_noimage.svg
            <?php endif; ?>
            " class="person-bullet-image person-bullet-component inline-image" title="<?php echo e(isset($user->name) ? $user->name : $user->login); ?>" alt="<?php echo e(isset($user->name) ? $user->name : $user->login); ?>">
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            
          <?php endif; ?>
        </div>
      </div>
      
    </div>
    <div class="board-group-cell status-cell">
      
      <div class="custom-select js-custom-select" style="background-color: orange;">
        <select name="status">
          <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($key); ?>"
            <?php if($key == $task->status): ?>
              selected="selected"
            <?php endif; ?>
            ><?php echo e($value); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
      
    </div>
    <div class="board-group-cell date-cell">
      <?php
        $task_date = '';
        if(!empty($task->date)){
          $task_date = $task->date->format('d.m.Y');
        }
      ?>
      <input type="text" name="date" value="<?php echo e($task_date); ?>" class='input-cell js-datepicker' readonly>
    </div>
    <div class="board-group-cell sum-cell">
      <input class="input-cell" type="text" name="sum" value="<?php echo e($task->sum); ?>" readonly>
    </div>
    <div class="board-group-cell btn-cell">
      <button class="btn btn-row-update">ok</button>
    </div>

  </div>
  </form>
