<?php $__env->startSection('content'); ?>

<div class="user__messages_container">
  <div class="user__messages_header">
    <h1>Сообщения</h1>
  </div>
  <div class="user__messages_inner-container">
    <div class="user__messages_content">
      <?php $__empty_1 = true; $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="user__messages_item">
          <div class="user__messages_content-header">
            <div class="user__messages_avatar">
              <div class="header__profile_image">
                <?php if( !empty($item->user->image) ): ?>
                <div class="header__profile_pic img-circle"
                  style="background:center / cover
                  no-repeat url('<?php echo e(asset('/storage/'.$item->user->image)); ?>')
                  ">
                </div>
                <?php else: ?>
                <div class="header__profile_pic img-circle">
                  <div class="profile-image-text">
                    <?php
                      echo substr($item->user->login, 0, 2);
                    ?>
                  </div>
                </div>
                <?php endif; ?>
              </div>
            </div>
            <div class="user__messages_name">
              <?php if( !empty( $item->user->name ) ): ?>
                <?php echo e($item->user->name); ?>

              <?php else: ?>
                <?php echo e($item->user->login); ?>

              <?php endif; ?>
            </div>
            <div class="user__messages_date">
              <?php echo e($item->created_at); ?>

            </div>
          </div>
          <div class="user__messages_content-main">
            <?php echo $item->message; ?>

          </div>

        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="user__messages_content-main">
          Сообщения отсутствуют.
        </div>
      <?php endif; ?>
      <ul class="pagination pull-right">
        <?php echo e($messages->links()); ?>

      </ul>
    </div>
  </div>
  <div class="user__messages_footer">
      <div class="btn btn-default js-open-write-message">Написать сообщение</div>
      <div class="write-message">
        <form class="write-message-form"
        action="<?php echo e(route('messages.store')); ?>" method="post">
          <?php echo e(csrf_field()); ?>

          <label for="">Сообщение</label>
          <textarea class="form-control tinymce" name="message"></textarea>

          <hr>

          <input class="btn btn-default" type="submit" value="Отправить">
          <div class="btn btn-default float-right js-close-write-message">Отмена</div>
        </form>
      </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('crm.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>