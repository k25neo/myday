<?php $__env->startSection('content'); ?>
    <div class="content__wrapper">
      <!-- begin mywork -->
      <div class="personal-assistant-component ">
        <div class="personal-assistant-content-header ">
          <div class="weeks-navigator-container">
            <div class="personal-assistant-weeks-navigator-component">
              
            </div>
          </div>
        </div>
        <div class="personal-assistant-content-view">
          <div class="personal-assistant-content-component">
            <div class="header-container">
              <div class="personal-assistant-header-component"><img src="/img/coffee_team.png" class="image-title">
                <div class="personal-assistant-titles">
                  <div class="first-title"><span>Привет <?php echo e(isset($user->name) ? $user->name : $user->login); ?>,</span></div>
                  <div class="second-title">
                    <?php if(count($tasks) > 0): ?>
                      <span>У вас <?php echo e(count($tasks)); ?> <?php echo e(Lang::choice('задание|задания|заданий', count($tasks))); ?></span>
                    <?php else: ?>
                      <span>У вас нет заданий</span>
                    <?php endif; ?>
                  </div>
                </div>
              </div>
              
            </div>
            <div class="deadlines-tasks-container">

              <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="deadline-tasks-section-component">
  
                  <div>
                    <div class="deadline-tasks-wrapper" style="display: block;">
                      <a href="<?php echo e(route('board.show', $task->group->board->id)); ?>">
                      <div class="deadline-task-component">
                        <div class="details">
                          <div class="pulse-name-wrapper"><span class="pulse-name-text">
                              <div class="ds-text-component" dir="auto"><span><?php echo e($task->name); ?></span></div>
                            </span></div>
                          <div class="deadline-task-path"><i class="fa fa-list" aria-hidden="true"></i>
                            <span class="board-name"><?php echo e($task->group->board->name); ?></span><span> &gt; </span><span
                              class="group-name"><?php echo e($task->group->name); ?></span></div>
                        </div>
                        <div class="deadline-task-columns">
                          <div class="persons-wrapper">
                            <div class="overlap-images-component">
                              <div class="overlap-images-wrapper">
                                
                              </div>
                            </div>
                          </div>
                          <div class="deadline-indication merged">
                            <div class="deadline-date-indication-icon-component">
                                <?php
                                  setlocale(LC_TIME, 'ru_RU.UTF-8');
                                ?>
                            </div><span class="deadline-time ">
                              <?php if(!empty($task->date)): ?>
                              <?php echo e($task->date->formatLocalized('%d %B %Y')); ?>

                              <?php endif; ?>
                            </span>
                          </div>
                        </div>
                      </div>
                      </a>
                    </div>
                  </div>
                </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


              
              

              

              
            </div>
          </div>
        </div>
      </div>
      <!-- end mywork -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('crm.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>