<?php $__env->startSection('content'); ?>
  <!-- begin personal info -->
  <div class="user__profile_container" id="user__profile_container">
    <div class="user__profile">
      <div class="user__profile_top-container">
        <div class="user__profile_top">
          <div class="user__profile_image-component">
            <?php if( !empty(Auth::user()->image) ): ?>
              <div class="hover-wrapper" style="background:center / cover
              no-repeat url('<?php echo e(asset('/storage/'.Auth::user()->image)); ?>')
              ">
                <div class="profile-image hover"></div>
            <?php else: ?>
              <div class="hover-wrapper">
                <div class="profile-image-text">
                  <?php
                    echo substr(Auth::user()->login, 0, 2);
                  ?>
                </div>
              <?php endif; ?>
              <form action="<?php echo e(route('profile.update', Auth::user()->id)); ?>"
                method="post" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('PUT')); ?>

                <input type="file" name="image" style="display:none">
              </form>
              <div class="change-picture-hover js-changePicture">
                <i class="fa fa-user-plus" aria-hidden="true"></i>
                <div class="change-picture-text">Сменить фото</div>
              </div>
            </div>
          </div>
          <div class="user__profile_name js-profileModal" data-id="name">
              <?php echo e(isset(Auth::user()->name) ?  Auth::user()->name : 'Задать имя'); ?>

              <div class="edit_icon_container"><i class="fa fa-pencil" aria-hidden="true"></i></div>
          </div>
        </div>
        <div class="user__profile_menu-container">
          <div class="user__profile_menu">
            <ul class="pulse-tabs ">
              <li class="is-selected" data-tab="contact_information">Персональная информация</li>
              <li data-tab="change_password">Пароль</li>
            </ul>
          </div>
        </div>
      </div>
      <div class="user__profile_middle-container">
        <div class="user__profile_inner-container">
          <div id="contact_information" class="contact_information pulse-tabs-data open">
            <div class="contact_information_container">
              <h2>Данные</h2>
              <div class="profile_get_in_touch_el">
                <div class="icon_container">
                  <div><i class="fa fa-user" aria-hidden="true"></i></div>
                </div>
                <div class="data_container popup_edit_link">
                  <div class="data_row_container">
                    <div class="profile-field-title">
                      <div class="ds-text-component" dir="auto"><span>Должность:</span></div>
                    </div>
                    <div class="profile-field-content js-profileModal" data-id="position" >

                      <?php if( !empty(Auth::user()->position) ): ?>
                        <span class="profile-field-value">
                            <?php echo e(Auth::user()->position); ?>

                        </span>
                      <?php else: ?>
                        <span class="profile-field-value missing">Добавить</span>
                      <?php endif; ?>

                      <div class="edit_icon_container"><i class="fa fa-pencil" aria-hidden="true"></i></div>

                    </div>
                  </div>
                </div>
              </div>
              <div class="profile_get_in_touch_el">
                <div class="icon_container">
                  <div><i class="fa fa-envelope-o" aria-hidden="true"></i></div>
                </div>
                <div class="data_container popup_edit_link">
                  <div class="data_row_container">
                    <div class="profile-field-title">
                      <div class="ds-text-component" dir="auto"><span>Email:</span></div>
                    </div>
                    <div class="profile-field-content js-profileModal" data-id="email">

                      <?php if( !empty(Auth::user()->email) ): ?>
                        <span class="profile-field-value">
                            <?php echo e(Auth::user()->email); ?>

                        </span>
                      <?php else: ?>
                        <span class="profile-field-value missing">Добавить</span>
                      <?php endif; ?>

                      <div class="edit_icon_container"><i class="fa fa-pencil" aria-hidden="true"></i></div>

                    </div>
                  </div>
                </div>
              </div>
              <div class="profile_get_in_touch_el">
                <div class="icon_container">
                  <div><i class="fa fa-phone" aria-hidden="true"></i></div>
                </div>
                <div class="data_container popup_edit_link">
                  <div class="data_row_container">
                    <div class="profile-field-title">
                      <div class="ds-text-component" dir="auto"><span>Телефон:</span></div>
                    </div>
                    <div class="profile-field-content js-profileModal" data-id="phone">

                      <?php if( !empty(Auth::user()->phone) ): ?>
                        <span class="profile-field-value">
                            <?php echo e(Auth::user()->phone); ?>

                        </span>
                      <?php else: ?>
                        <span class="profile-field-value missing">Добавить</span>
                      <?php endif; ?>

                      <div class="edit_icon_container"><i class="fa fa-pencil" aria-hidden="true"></i></div>

                    </div>
                  </div>
                </div>
              </div>
              <div class="profile_get_in_touch_el">
                <div class="icon_container">
                  <div><i class="fa fa-clock-o" aria-hidden="true"></i></div>
                </div>
                <div class="data_container popup_edit_link">
                  <div class="data_row_container">
                    <div class="profile-field-title">
                      <div class="ds-text-component" dir="auto"><span>Часовой пояс:</span></div>
                    </div>
                    <div class="profile-field-content js-profileModal" data-id="timezone">

                      <?php if( !empty($nameTimezone) ): ?>
                        <span class="profile-field-value">
                            <?php echo e($nameTimezone); ?>

                        </span>
                      <?php else: ?>
                        <span class="profile-field-value missing">Добавить</span>
                      <?php endif; ?>

                      <div class="edit_icon_container"><i class="fa fa-pencil" aria-hidden="true"></i></div>

                    </div>
                  </div>
                </div>
              </div>
              <div class="profile_get_in_touch_el">
                <div class="icon_container">
                  <div><i class="fa fa-birthday-cake" aria-hidden="true"></i></div>
                </div>
                <div class="data_container popup_edit_link">
                  <div class="data_row_container">
                    <div class="profile-field-title">
                      <div class="ds-text-component" dir="auto"><span>День рождения:</span></div>
                    </div>
                    <div class="profile-field-content js-profileModal" data-id="birthday">

                      <?php if( !empty($birthday) ): ?>
                        <span class="profile-field-value ">
                            <?php echo e($birthday); ?>

                        </span>
                      <?php else: ?>
                        <span class="profile-field-value missing">Добавить</span>
                      <?php endif; ?>

                      <div class="edit_icon_container"><i class="fa fa-pencil" aria-hidden="true"></i></div>

                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div id="change_password" class="change_password pulse-tabs-data">
            <section class="user_profile_bottom_container">
              <div class="user_inner_container change_password">
                <h1>Смена пароля</h1>

                <form action="<?php echo e(route('profile.changepass', Auth::user()->id)); ?>" method="post">
                  <?php echo e(csrf_field()); ?>

                  <?php echo e(method_field('PUT')); ?>

                  <div class="input_container">
                    <div class="label"><label for="current_password">Текущий пароль</label></div>
                    <div class="input">
                      <input type="password" class="form-control"
                      id="current_password" name="current_password">
                    </div>
                  </div>
                  <div class="input_container">
                    <div class="label"><label for="new_password">Новый пароль</label></div>
                    <div class="input password_status_empty">
                      <input type="password" class="form-control"
                        id="new_password" name="new_password">
                      <div class="progress">
                        <div class="progress-bar"></div>
                      </div><span class="password-verdict"></span>
                    </div>
                  </div>
                  <div></div>
                  <div class="input_container">
                    <div class="label"><label for="password_confirmation">Подтвердить новый пароль</label></div>
                    <div class="input">
                      <input type="password" class="form-control"
                        id="new_password_confirmation" name="new_password_confirmation">
                    </div>
                  </div>
                  <div></div>
                  <div class="separetor_line"></div>
                  <div class="action_button_container"><button type="submit"
                      class="ds-btn ds-btn-primary">Сохранить</button></div>
                </form>
              </div>
            </section>
          </div>
        </div>
      </div>
    </div>


  </div>
  <!-- end personal info -->
<?php $__env->stopSection(); ?>

<?php if(session('status')): ?>
  <?php $__env->startSection('message_modal'); ?>
    <!-- start modals -->
    <div class="ReactModalPortal open">
      <div class="ReactModal__Overlay ReactModal__Overlay--after-open"
        style="position: fixed; inset: 0; background-color: rgba(255, 255, 255, 0.75);">
        <div
          style="position: absolute; border: 1px solid rgb(204, 204, 204); background: rgb(255, 255, 255) none repeat scroll 0 0; overflow: visible; border-radius: 4px; outline: currentcolor none medium; padding: 0;"
          class="ReactModal__Content ReactModal__Content--after-open" tabindex="-1" role="dialog"
          aria-label="UserProfilePersonalInfoModal">
          <div class="react_popup_wrapper ">
            <div class="close_button"></div>
            <div>
              <div class="form_title"><label>Сообщение</label></div>
              <div class="alert alert-success">
                <?php echo e(session('status')); ?>

              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  <?php $__env->stopSection(); ?>
<?php endif; ?>

<?php if(count($errors) > 0): ?>
  <?php $__env->startSection('error_modal'); ?>
    <!-- start modals -->
    <div class="ReactModalPortal open">
      <div class="ReactModal__Overlay ReactModal__Overlay--after-open"
        style="position: fixed; inset: 0; background-color: rgba(255, 255, 255, 0.75);">
        <div
          style="position: absolute; border: 1px solid rgb(204, 204, 204); background: rgb(255, 255, 255) none repeat scroll 0 0; overflow: visible; border-radius: 4px; outline: currentcolor none medium; padding: 0;"
          class="ReactModal__Content ReactModal__Content--after-open" tabindex="-1" role="dialog"
          aria-label="UserProfilePersonalInfoModal">
          <div class="react_popup_wrapper ">
            <div class="close_button"></div>
            <div>
              <div class="form_title"><label>Ошибка</label></div>
              <div class="alert alert-danger">
                <ul>
                  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  <?php $__env->stopSection(); ?>

<?php endif; ?>

<?php $__env->startSection('profile_modal'); ?>
  <!-- start modals -->
  <div id="profile_modal" class="ReactModalPortal">
    <div class="ReactModal__Overlay ReactModal__Overlay--after-open"
      style="position: fixed; inset: 0; background-color: rgba(255, 255, 255, 0.75);">
      <div
        style="position: absolute; border: 1px solid rgb(204, 204, 204); background: rgb(255, 255, 255) none repeat scroll 0 0; overflow: visible; border-radius: 4px; outline: currentcolor none medium; padding: 0;"
        class="ReactModal__Content ReactModal__Content--after-open" tabindex="-1" role="dialog"
        aria-label="UserProfilePersonalInfoModal">
        <div class="react_popup_wrapper ">
          <div class="close_button"></div>
          <div>
            <form action="<?php echo e(route('profile.update', Auth::user()->id)); ?>" method="post">
              <?php echo e(csrf_field()); ?>

              <?php echo e(method_field('PUT')); ?>


              
              <div class="form__input_container" data-id="name">
                <div class="form_title"><label>Имя</label></div>
                <div class="inline_form">
                  <div class="form_line_container">
                    <input class="form-control fullwidth" name="name"
                    value="<?php echo e(isset(Auth::user()->name) ?  Auth::user()->name : ''); ?>">
                  </div>
                </div>
              </div>
              
              <div class="form__input_container" data-id="position">
                <div class="form_title"><label>Должность</label></div>
                <div class="inline_form">
                  <div class="form_line_container">
                    <input class="form-control fullwidth" name="position"
                    value="<?php echo e(isset(Auth::user()->position) ?  Auth::user()->position : ''); ?>">
                  </div>
                </div>
              </div>
              
              <div class="form__input_container" data-id="email">
                <div class="form_title"><label>Email</label></div>
                <div class="inline_form">
                  <div class="form_line_container">
                    <input class="form-control fullwidth" name="email"
                    value="<?php echo e(isset(Auth::user()->email) ?  Auth::user()->email : ''); ?>">
                  </div>
                </div>
              </div>
              
              <div class="form__input_container" data-id="phone">
                <div class="form_title"><label>Телефон</label></div>
                <div class="inline_form">
                  <div class="form_line_container">
                    <input class="form-control fullwidth" name="phone" placeholder="+7(___) ___-__-__"
                    value="<?php echo e(isset(Auth::user()->phone) ?  Auth::user()->phone : ''); ?>">
                  </div>
                </div>
              </div>
              
              <div class="form__input_container" data-id="timezone">
                <div class="form_title"><label>Часовой пояс</label></div>
                <div class="inline_form">
                  <div class="form_line_container">
                    <?php echo $selectTimezone; ?>

                  </div>
                </div>
              </div>
              
              <div class="form__input_container" data-id="birthday">
                <div class="form_title"><label>День рождения</label></div>
                <div class="inline_form">
                  <div class="form_line_container">
                    <input class="form-control fullwidth js-datepicker"
                    name="birthday"
                    data-startDate="<?php echo e(isset($birthday) ?  $birthday : ''); ?>"
                    value="<?php echo e(isset($birthday) ?  $birthday : ''); ?>">
                  </div>
                </div>
              </div>

              <div class="action_button_container">
                <button type="submit" class="ds-btn ds-btn-primary">Сохранить</button>
              </div>

            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- end modals -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('crm.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>