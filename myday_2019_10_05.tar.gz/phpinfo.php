<?php symlink('/home/f0296392/domains/f0296392.xsph.ru/public_html/storage/app/public', '/home/f0296392/domains/f0296392.xsph.ru/public_html/public/storage');
